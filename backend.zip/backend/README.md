# BestCropPrice Backend

This backend does not train models during install time. Training happens only when you run:

- `python train_all.py` for local training
- `python train_kaggle.py` for Kaggle training and export

## Local Setup With `venv`

From the repository root:

```bash
cd backend
bash setup_venv.sh
source .venv/bin/activate
```

Then run:

```bash
python train_all.py
python api.py
```

## Kaggle Training Flow

The intended Kaggle entrypoint is:

```bash
python train_kaggle.py
```

What it does:

1. Loads `backend/data/coimbatore_maize_model_daily.csv`
2. Trains and evaluates all four candidate models
3. Selects the best model by test RMSE
4. Retrains the winning model on the full dataset
5. Writes model artifacts into `backend/models/`
6. Writes reports and CSV outputs into `backend/outputs/`
7. Creates `backend/bestcropprice_outputs.zip`
8. Prints the absolute ZIP path at the end

The ZIP contains both:

- `models/`
- `outputs/`

## Kaggle Notebook Example

If this repository is copied into `/kaggle/working/BestCropPrice`, run:

```bash
cd /kaggle/working/BestCropPrice/backend
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python train_kaggle.py
```

After training, download:

```text
/kaggle/working/BestCropPrice/backend/bestcropprice_outputs.zip
```

## API

After local training:

```bash
python api.py
```

The Flask API runs on port `5000`.
